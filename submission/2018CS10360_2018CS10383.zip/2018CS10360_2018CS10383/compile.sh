gcc -fopenmp -o ompver ompver.c
mpicc -fopenmp -o mpiver mpiver.c
